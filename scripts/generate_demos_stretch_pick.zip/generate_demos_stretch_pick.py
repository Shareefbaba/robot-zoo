import argparse
from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--num_demos",  type=int, default=100)
parser.add_argument("--output_dir", type=str,
    default="/home/shareef/robot_zoo/data/demos/stretch_pick_cube")
AppLauncher.add_app_launcher_args(parser)
args_cli = parser.parse_args()
app_launcher = AppLauncher(args_cli)
simulation_app = app_launcher.app

import sys, torch, random
import isaaclab.sim as sim_utils
from isaaclab.sim import SimulationContext
from isaaclab.assets import Articulation, RigidObject, RigidObjectCfg

sys.path.insert(0, "/home/shareef")
from robot_zoo.data.recorder import EpisodeRecorder
from robot_zoo.envs.stretch_cfg import STRETCH_CFG

# Joint indices
IDX_LIFT     = 2
IDX_ARM_L3   = 5; IDX_ARM_L2 = 6; IDX_ARM_L1 = 7; IDX_ARM_L0 = 8
IDX_WRIST    = 9
IDX_GRIP_L   = 10; IDX_GRIP_R = 11

OPEN  =  0.6
CLOSE = -0.6

# From body position analysis:
# Robot at (rx, ry, 0) with 180deg Z rotation:
#   arm extends in +Y direction
#   grasp_center at (rx-0.084, ry+0.665, 0.026) at full extension + lift=0
# Strategy: approach from ABOVE to avoid pushing cube

def main():
    sim = SimulationContext(sim_utils.SimulationCfg(dt=0.02, render_interval=2))
    sim.set_camera_view(eye=[1.5, 1.5, 1.2], target=[0.5, 0.0, 0.1])

    sim_utils.GroundPlaneCfg().func("/World/GroundPlane", sim_utils.GroundPlaneCfg())
    stretch = Articulation(STRETCH_CFG.replace(prim_path="/World/Stretch"))

    cube_cfg = RigidObjectCfg(
        prim_path="/World/Cube",
        spawn=sim_utils.CuboidCfg(
            size=(0.06, 0.06, 0.06),  # slightly bigger cube = easier to grasp
            rigid_props=sim_utils.RigidBodyPropertiesCfg(),
            mass_props=sim_utils.MassPropertiesCfg(mass=0.05),  # lighter
            collision_props=sim_utils.CollisionPropertiesCfg(),
            visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(1.0, 0.0, 0.0)),
        ),
        init_state=RigidObjectCfg.InitialStateCfg(pos=(0.5, 0.0, 0.03)),
    )
    cube = RigidObject(cube_cfg)
    sim.reset()
    stretch.update(sim.get_physics_dt())
    cube.update(sim.get_physics_dt())

    recorder = EpisodeRecorder(output_dir=args_cli.output_dir,
                               task="pick_cube", robot="stretch")

    num_demos = args_cli.num_demos
    collected = recorder._ep_idx
    attempted = 0
    print(f"Collecting {num_demos} Stretch pick-cube demonstrations.")
    device = sim.device

    while collected < num_demos and simulation_app.is_running():
        # Randomize cube
        cx = random.uniform(0.45, 0.60)
        cy = random.uniform(-0.08, 0.08)

        cube.write_root_pose_to_sim(torch.tensor(
            [[cx, cy, 0.03, 1.0, 0.0, 0.0, 0.0]], device=device))

        # Robot: 180deg Z rotation, arm extends in +Y
        # grasp_center_y = ry + 0.665, grasp_center_x = rx - 0.084
        # So: rx = cx - 0.227, ry = cy - 0.665
        rx = cx - 0.227
        ry = cy - 0.665
        stretch.write_root_pose_to_sim(torch.tensor(
            [[rx, ry, 0.0, 0.0, 0.0, 0.0, 1.0]], device=device))  # 180deg Z

        # Default joints
        jt = torch.zeros(1, 12, device=device)
        jt[0, IDX_LIFT]  = 0.3
        jt[0, IDX_WRIST] = -1.57
        jt[0, IDX_GRIP_L] = OPEN
        jt[0, IDX_GRIP_R] = OPEN
        stretch.set_joint_position_target(jt)
        stretch.write_data_to_sim()

        for _ in range(40):  # warmup
            sim.step()
            stretch.update(sim.get_physics_dt())
            cube.update(sim.get_physics_dt())

        # === PHASE 1: Extend arm at HIGH lift (above cube) ===
        jt[0, IDX_LIFT]  = 0.18  # above cube (cube top = 0.06m)
        jt[0, IDX_ARM_L3] = 0.13
        jt[0, IDX_ARM_L2] = 0.13
        jt[0, IDX_ARM_L1] = 0.13
        jt[0, IDX_ARM_L0] = 0.13
        jt[0, IDX_GRIP_L] = OPEN
        jt[0, IDX_GRIP_R] = OPEN

        for _ in range(100):
            stretch.set_joint_position_target(jt)
            stretch.write_data_to_sim()
            sim.step()
            stretch.update(sim.get_physics_dt())
            cube.update(sim.get_physics_dt())
            recorder.record_step(stretch.data.joint_pos[0],
                                 stretch.data.joint_vel[0],
                                 cube.data.root_pos_w[0],
                                 jt[0], 0.0)

        # === PHASE 2: Lower down onto cube ===
        jt[0, IDX_LIFT] = 0.0
        for _ in range(80):
            stretch.set_joint_position_target(jt)
            stretch.write_data_to_sim()
            sim.step()
            stretch.update(sim.get_physics_dt())
            cube.update(sim.get_physics_dt())
            recorder.record_step(stretch.data.joint_pos[0],
                                 stretch.data.joint_vel[0],
                                 cube.data.root_pos_w[0],
                                 jt[0], 0.0)

        # === PHASE 3: Close gripper ===
        jt[0, IDX_GRIP_L] = CLOSE
        jt[0, IDX_GRIP_R] = CLOSE
        for _ in range(60):
            stretch.set_joint_position_target(jt)
            stretch.write_data_to_sim()
            sim.step()
            stretch.update(sim.get_physics_dt())
            cube.update(sim.get_physics_dt())
            recorder.record_step(stretch.data.joint_pos[0],
                                 stretch.data.joint_vel[0],
                                 cube.data.root_pos_w[0],
                                 jt[0], 0.0)

        # === PHASE 4: Lift ===
        jt[0, IDX_LIFT] = 0.4
        max_z = 0.0
        for _ in range(100):
            stretch.set_joint_position_target(jt)
            stretch.write_data_to_sim()
            sim.step()
            stretch.update(sim.get_physics_dt())
            cube.update(sim.get_physics_dt())
            cz = cube.data.root_pos_w[0, 2].item()
            max_z = max(max_z, cz)
            recorder.record_step(stretch.data.joint_pos[0],
                                 stretch.data.joint_vel[0],
                                 cube.data.root_pos_w[0],
                                 jt[0], float(cz > 0.10))

        attempted += 1
        success = max_z > 0.10
        if success:
            recorder.save_episode(success=True)
            collected += 1
            print(f"  demo {collected:3d}/{num_demos} | max_z={max_z:.3f} | attempts={attempted}")
        else:
            recorder.discard_episode()
            print(f"  FAILED attempt {attempted} | max_z={max_z:.3f}")

    recorder.save_metadata(total_episodes=collected,
                           success_rate=collected/max(attempted,1))
    print(f"\nDone: {collected} demos | {100*collected/max(attempted,1):.1f}% success")


if __name__ == "__main__":
    main()
    simulation_app.close()
